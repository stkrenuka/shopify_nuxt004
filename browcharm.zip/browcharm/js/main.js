   function changeImage(imageSrc) {
    document.getElementById('mainImage').src = imageSrc;
  }

  function changeImage(imageSrc, button) {
    document.getElementById('mainImage').src = imageSrc;

    document.querySelectorAll('button').forEach(btn => {
      btn.classList.remove('border-2', 'border-black');
    });

    button.classList.add('border-2', 'border-black');
  }

   function setActive(button) {
    document.querySelectorAll('.option-btn').forEach(btn => {
      btn.classList.remove('border-2', 'border-black');
    });


    button.classList.add('border-2', 'border-black');
  }
    
    const menuToggle = document.getElementById('menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');

    menuToggle.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });
    const imgs = document.querySelectorAll('.img-select a');
const imgBtns = [...imgs];
let imgId = 1;

imgBtns.forEach((imgItem) => {
    imgItem.addEventListener('click', (event) => {
        event.preventDefault();
        imgId = imgItem.dataset.id;
        slideImage();
    });
});

function slideImage(){
    const displayWidth = document.querySelector('.img-showcase img:first-child').clientWidth;

    document.querySelector('.img-showcase').style.transform = `translateX(${- (imgId - 1) * displayWidth}px)`;
}

window.addEventListener('resize', slideImage);

        const openSearch = document.getElementById('openSearch');
        const closeSearch = document.getElementById('closeSearch');
        const searchOverlay = document.getElementById('searchOverlay');

        // Open Search
        openSearch.addEventListener('click', () => {
            searchOverlay.classList.remove('hidden');
            document.body.style.overflow = 'hidden'; // Disable scroll
        });

        // Close Search
        closeSearch.addEventListener('click', () => {
            searchOverlay.classList.add('hidden');
            document.body.style.overflow = 'auto'; // Enable scroll
        });
  const accordionButtons = document.querySelectorAll('.accordion-button');

  accordionButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const content = button.nextElementSibling;
      const icon = button.querySelector('.accordion-icon');

      // Close all other accordions
      accordionButtons.forEach((btn) => {
        if (btn !== button) {
          btn.setAttribute('aria-expanded', 'false');
          btn.nextElementSibling.classList.add('hidden');
          btn.querySelector('.accordion-icon').classList.remove('rotate-180');
        }
      });

      // Toggle current accordion
      const isExpanded = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', !isExpanded);
      content.classList.toggle('hidden');
      icon.classList.toggle('rotate-180');
    });
  });